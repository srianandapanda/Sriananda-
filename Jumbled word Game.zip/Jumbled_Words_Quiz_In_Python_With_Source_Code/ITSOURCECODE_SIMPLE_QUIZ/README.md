# IT SOURCECODE --->> Jumbled Words Quiz

To run the program follow the following steps 
1.Download ZIP file 
2.Extract ZIP file 
3.Click on ITSOURCECOE_SIMPLE_QUIZ
4.Click on main_start
